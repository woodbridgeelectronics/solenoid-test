Gerber file definition:
=======================================
Top Layer: pcbname.GTL
Top Solder Mask: pcbname.GTS
Top Silkscreen: pcbname.GTO

Bottom Layer: pcbname.GBL
Bottom Solder Mask?: pcbname.GBS
Bottom silkscreen: pcbname.GBO
Board Outline:pcbname.GML/GKO

Drills: pcbname.TXT


slot milling refers to board outline file.