/*




void solenoid_control(uint8_t i, Solenoid_Ctl *sol_i)
{	
	// sensor AB de-bounce
	if(sol_i->solenoid_state == SOLEN_OFF)
	{
		if(sol_i->sensorA_state==sol_i->sensorA_state_off && sol_i->sensorB_state==sol_i->sensorB_state_off) {// sensor at OFF state
			sol_i->sensor_dbn_cnt ++;
		}
		else {
			sol_i->sensor_dbn_cnt = 0;
			sol_i->solen_off_cnt ++;	// solenoid switching OFF but not sensed yet
		}
	}

	if(sol_i->solenoid_state == SOLEN_ON)
	{
		if(sol_i->sensorA_state!=sol_i->sensorA_state_off && sol_i->sensorB_state!=sol_i->sensorB_state_off) { // sensor at ON state
			sol_i->sensor_dbn_cnt ++;
		}
		else {
			sol_i->sensor_dbn_cnt = 0;
			sol_i->solen_on_cnt ++;	// solenoid switching ON but not sensed yet
		}
	}
	
	if(sol_i->sensor_dbn_cnt==TIME_ONE_MILI_SEC*1000) { // delay 1 sec
		if(sol_i->solenoid_state == SOLEN_ON) { // was ON
			sol_i->solenoid_state = SOLEN_OFF;
			sol_i->test_wdog_cnt = 0; // clear watchdog
			sol_i->test_loop_cnt ++;
			ROM_GPIOPinWrite(PORT_LED, PIN_LED_RED, 0x00);
		}
		else {
			if(sol_i->test_loop_cnt < sol_i->loop_cnt_setting) { // was OFF
				sol_i->solenoid_state  = SOLEN_ON;
				sol_i->test_wdog_cnt = 0; // clear watchdog
			}
			if(sol_i->test_loop_cnt > 0)
				UARTprintf("C%u L%u ON%u OFF%u\n", i,
						sol_i->test_loop_cnt, (uint32_t)(sol_i->solen_on_cnt/10), (uint32_t)(sol_i->solen_off_cnt/10));
			sol_i->solen_on_cnt = 0;
			sol_i->solen_off_cnt = 0;
		}

		set_solen_on_off(i, sol_i->solenoid_state);
	}
	
	// watchdog enabled only when the CH is used and running
	if(sol_i->test_loop_cnt>0 && sol_i->test_loop_cnt<sol_i->loop_cnt_setting) {
		sol_i->test_wdog_cnt ++;
	}
	else {
		sol_i->test_wdog_cnt = 0;
	}

	if(sol_i->test_wdog_cnt == TIME_ONE_MILI_SEC*1000*4) {
		UARTprintf("C%u stuck\n", i);
		ROM_GPIOPinWrite(PORT_LED, PIN_LED_RED, PIN_LED_RED);
	}
}
*/
//*****************************************************************************
//
// timers.c - Timers example.
//
// Copyright (c) 2012-2016 Texas Instruments Incorporated.  All rights reserved.
// Software License Agreement
//
// Texas Instruments (TI) is supplying this software for use solely and
// exclusively on TI's microcontroller products. The software is owned by
// TI and/or its suppliers, and is protected under applicable copyright
// laws. You may not combine this software with "viral" open-source
// software in order to form a larger program.
//
// THIS SOFTWARE IS PROVIDED "AS IS" AND WITH ALL FAULTS.
// NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. TI SHALL NOT, UNDER ANY
// CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
// DAMAGES, FOR ANY REASON WHATSOEVER.
//
// This is part of revision 2.1.3.156 of the EK-TM4C123GXL Firmware Package.
//
//*****************************************************************************

#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include "project.h"

#include "inc/hw_ints.h"
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "driverlib/debug.h"
#include "driverlib/fpu.h"
#include "driverlib/gpio.h"
#include "driverlib/interrupt.h"
#include "driverlib/pin_map.h"
#include "driverlib/rom.h"
#include "driverlib/sysctl.h"
#include "driverlib/timer.h"
#include "driverlib/uart.h"
#include "utils/uartstdio.h"


uint32_t    test_time_cnt;              // test duration counter 2^32 *100u / (24*60*60) = 5 days


typedef struct Solenoids {
    uint8_t     solenoid_state;         // solenoid ON/OFF state
    uint32_t    solen_on_cnt;         	// solenoid switching on speed
    uint32_t    solen_off_cnt;         	// solenoid switching off speed
	
    uint8_t     sensorA_state;          // solenoid sensor A state
    uint8_t     sensorB_state;          // solenoid sensor B state
    uint8_t     sensorA_state_off;      // solenoid sensor A state
    uint8_t     sensorB_state_off;      // solenoid sensor B state
    uint32_t    sensor_dbn_cnt;         // solenoid debounce counter
    uint32_t    test_loop_cnt;          // test loop counter
    uint32_t    test_wdog_cnt;          // test watchdog counter
    uint32_t    loop_cnt_setting;       // no of test to run
	uint8_t		test_error;				// 
} Solenoid_Ctl;


//*****************************************************************************
//
//! \addtogroup example_list
//! <h1>Timer (timers)</h1>
//!
//! This example application demonstrates the use of the timers to generate
//! periodic interrupts.  One timer is set up to interrupt once per second and
//! the other to interrupt twice per second; each interrupt handler will toggle
//! its own indicator on the display.
//!
//! UART0, connected to the Virtual Serial Port and running at 115,200, 8-N-1,
//! is used to display messages from this application.
//
//*****************************************************************************

//*****************************************************************************
//
// Flags that contain the current value of the interrupt indicator as displayed
// on the UART.
//
//*****************************************************************************
uint32_t g_ui32Flags;
volatile uint32_t g_ui32Timer0Int;



//*****************************************************************************
//
// The error routine that is called if the driver library encounters an error.
//
//*****************************************************************************
#ifdef DEBUG
void
__error__(char *pcFilename, uint32_t ui32Line)
{
}
#endif


//*****************************************************************************
//
// The interrupt handler for the first timer interrupt.
//
//*****************************************************************************
void
Timer0IntHandler(void)
{
    //
    // Clear the timer interrupt.
    //
    ROM_TimerIntClear(TIMER0_BASE, TIMER_TIMA_TIMEOUT);

    //
    // Set interrupt triggered flag
    //
    g_ui32Timer0Int = 1;

}



//*****************************************************************************
//
// Configure the UART and its pins.  This must be called before UARTprintf().
//
//*****************************************************************************
void
ConfigureUART(void)
{
    //
    // Enable the GPIO Peripheral used by the UART.
    //
    ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);

    //
    // Enable UART0
    //
    ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);

    //
    // Configure GPIO Pins for UART mode.
    //
    ROM_GPIOPinConfigure(GPIO_PA0_U0RX);
    ROM_GPIOPinConfigure(GPIO_PA1_U0TX);
    ROM_GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);

    //
    // Use the internal 16MHz oscillator as the UART clock source.
    //
    UARTClockSourceSet(UART0_BASE, UART_CLOCK_PIOSC);

    //
    // Initialize the UART for console I/O.
    //
    UARTStdioConfig(0, 115200, 16000000);
}



uint32_t power_of_ten(uint8_t pwr)
{
	uint8_t i;
	uint32_t temp = 1;
	
	for(i=1; i<=pwr; i++)
		temp *= 10;
	
	return temp;
}


bool is_ascii_digit(uint8_t ascii_digit)
{
	if(ascii_digit<='9' && ascii_digit>='0')
	{
		return true;
	}
	else
	{
		return false;
	}
}




void set_solen_on_off(uint8_t ch, uint8_t on_off)
{
    if(ch == 0)
        ROM_GPIOPinWrite(PORT_SOL_OUT0, PIN_SOL_OUT0, on_off);
    else if(ch == 1)
        ROM_GPIOPinWrite(PORT_SOL_OUT1, PIN_SOL_OUT1, on_off);
    else if(ch == 2)
        ROM_GPIOPinWrite(PORT_SOL_OUT2, PIN_SOL_OUT2, on_off);
    else if(ch == 3)
        ROM_GPIOPinWrite(PORT_SOL_OUT3, PIN_SOL_OUT3, on_off);
    else if(ch == 4)
        ROM_GPIOPinWrite(PORT_SOL_OUT4, PIN_SOL_OUT4, on_off);
    else if(ch == 5)
        ROM_GPIOPinWrite(PORT_SOL_OUT5, PIN_SOL_OUT5, on_off);
    else if(ch == 6)
        ROM_GPIOPinWrite(PORT_SOL_OUT6, PIN_SOL_OUT6, on_off);
    else if(ch == 7)
        ROM_GPIOPinWrite(PORT_SOL_OUT7, PIN_SOL_OUT7, on_off);
    else if(ch == 8)
        ROM_GPIOPinWrite(PORT_SOL_OUT8, PIN_SOL_OUT8, on_off);
    else if(ch == 9)
        ROM_GPIOPinWrite(PORT_SOL_OUT9, PIN_SOL_OUT9, on_off);
}



void get_senseAB_state(Solenoid_Ctl *sol)
{
	
	sol[0].sensorA_state = (uint8_t) ROM_GPIOPinRead(PORT_SOL_IN0_A, PIN_SOL_IN0_A);
    sol[1].sensorA_state = (uint8_t) ROM_GPIOPinRead(PORT_SOL_IN1_A, PIN_SOL_IN1_A); 
    sol[2].sensorA_state = (uint8_t) ROM_GPIOPinRead(PORT_SOL_IN2_A, PIN_SOL_IN2_A); 
    sol[3].sensorA_state = (uint8_t) ROM_GPIOPinRead(PORT_SOL_IN3_A, PIN_SOL_IN3_A); 
    sol[4].sensorA_state = (uint8_t) ROM_GPIOPinRead(PORT_SOL_IN4_A, PIN_SOL_IN4_A); 
    sol[5].sensorA_state = (uint8_t) ROM_GPIOPinRead(PORT_SOL_IN5_A, PIN_SOL_IN5_A); 
    sol[6].sensorA_state = (uint8_t) ROM_GPIOPinRead(PORT_SOL_IN6_A, PIN_SOL_IN6_A); 
    sol[7].sensorA_state = (uint8_t) ROM_GPIOPinRead(PORT_SOL_IN7_A, PIN_SOL_IN7_A); 
    sol[8].sensorA_state = (uint8_t) ROM_GPIOPinRead(PORT_SOL_IN8_A, PIN_SOL_IN8_A); 
    sol[9].sensorA_state = (uint8_t) ROM_GPIOPinRead(PORT_SOL_IN9_A, PIN_SOL_IN9_A);

    sol[0].sensorB_state = (uint8_t) ROM_GPIOPinRead(PORT_SOL_IN0_B, PIN_SOL_IN0_B); 
    sol[1].sensorB_state = (uint8_t) ROM_GPIOPinRead(PORT_SOL_IN1_B, PIN_SOL_IN1_B); 
    sol[2].sensorB_state = (uint8_t) ROM_GPIOPinRead(PORT_SOL_IN2_B, PIN_SOL_IN2_B); 
    sol[3].sensorB_state = (uint8_t) ROM_GPIOPinRead(PORT_SOL_IN3_B, PIN_SOL_IN3_B); 
    sol[4].sensorB_state = (uint8_t) ROM_GPIOPinRead(PORT_SOL_IN4_B, PIN_SOL_IN4_B); 
    sol[5].sensorB_state = (uint8_t) ROM_GPIOPinRead(PORT_SOL_IN5_B, PIN_SOL_IN5_B); 
    sol[6].sensorB_state = (uint8_t) ROM_GPIOPinRead(PORT_SOL_IN6_B, PIN_SOL_IN6_B); 
    sol[7].sensorB_state = (uint8_t) ROM_GPIOPinRead(PORT_SOL_IN7_B, PIN_SOL_IN7_B); 
    sol[8].sensorB_state = (uint8_t) ROM_GPIOPinRead(PORT_SOL_IN8_B, PIN_SOL_IN8_B); 
    sol[9].sensorB_state = (uint8_t) ROM_GPIOPinRead(PORT_SOL_IN9_B, PIN_SOL_IN9_B);
}



void print_result(Solenoid_Ctl *sol_t, uint32_t test_time_cnt)
{
	uint8_t i;
	
	for(i=0; i<10; i++)
	{
		UARTprintf("C%u L%u ON%u OFF%u\n", i,
			sol_t[i].test_loop_cnt, (uint32_t)(sol_t->solen_on_cnt/10), (uint32_t)(sol_t->solen_off_cnt/10));
	}

}



void solenoid_control_v2(uint8_t i, Solenoid_Ctl *sol_i, uint8_t on_error)
{	
	// watchdog enabled only when the CH is used and running
	if(sol_i->test_loop_cnt < sol_i->loop_cnt_setting) {		
		if(on_error!='0' && sol_i->test_error==ERROR_SET) { // stop on error && error occurs
			sol_i->test_wdog_cnt = 0;
		}
		else {
			sol_i->test_wdog_cnt ++;
		}
	}
	else {
		sol_i->test_wdog_cnt = 0;
	}
	
	if(sol_i->solenoid_state == SOLEN_OFF)
	{
		if(sol_i->sensorA_state==sol_i->sensorA_state_off && sol_i->sensorB_state==sol_i->sensorB_state_off) {// sensor at OFF state
			sol_i->sensor_dbn_cnt ++;
		}
		else {
			sol_i->sensor_dbn_cnt = 0;
			sol_i->solen_off_cnt ++;	// solenoid switching OFF but not sensed yet
		}
	}
	else { // sol_i->solenoid_state == SOLEN_ON
		if(sol_i->sensorA_state!=sol_i->sensorA_state_off && sol_i->sensorB_state!=sol_i->sensorB_state_off) { // sensor at ON state
			sol_i->sensor_dbn_cnt ++;
		}
		else {
			sol_i->sensor_dbn_cnt = 0;
			sol_i->solen_on_cnt ++;	// solenoid switching ON but not sensed yet
		}
	}
	
	if(sol_i->sensor_dbn_cnt==TIME_ONE_MILI_SEC*1000) { // delay 1 sec
		sol_i->test_wdog_cnt = 0; // clear dog

		if(sol_i->solenoid_state == SOLEN_ON) { // ON to OFF
			sol_i->solenoid_state = SOLEN_OFF;
			
			if(sol_i->test_error == NO_ERROR) { // no error occurs
				sol_i->test_loop_cnt ++;
				ROM_GPIOPinWrite(PORT_LED, PIN_LED_RED, 0x00);
			}
			else if(sol_i->test_error == ERROR_CLR1) { // 2nd step to clear error
				sol_i->test_error = NO_ERROR;
			}
		}
		else { // OFF to ON
			if(sol_i->test_loop_cnt < sol_i->loop_cnt_setting) { // was OFF
				sol_i->solenoid_state  = SOLEN_ON;			
			}
			
			if(sol_i->test_error == NO_ERROR) { // no error occurs
				UARTprintf("P,%u,%u,%u,%u\n", i, sol_i->test_loop_cnt, (uint32_t)(sol_i->solen_on_cnt/10), (uint32_t)(sol_i->solen_off_cnt/10));
				sol_i->solen_on_cnt = 0;
				sol_i->solen_off_cnt = 0;
			}
			else if(sol_i->test_error == ERROR_SET) { // 1st step to clear error
				sol_i->test_error = ERROR_CLR1;
			}			
		}

	set_solen_on_off(i, sol_i->solenoid_state);
	
	}
	
	if(sol_i->test_wdog_cnt == TIME_ONE_MILI_SEC*1000*5) { // watchdog expires
		sol_i->test_wdog_cnt = 0; // clear watchdog
		sol_i->test_error = ERROR_SET;	
		ROM_GPIOPinWrite(PORT_LED, PIN_LED_RED, PIN_LED_RED);
		
		if(on_error == '0') { // continue on error
			if(sol_i->solenoid_state == SOLEN_ON) { // ON to OFF
				sol_i->solenoid_state = SOLEN_OFF;
				sol_i->test_loop_cnt ++;
			}
			else { // OFF to ON
				if(sol_i->test_loop_cnt < sol_i->loop_cnt_setting) { // was OFF
					sol_i->solenoid_state  = SOLEN_ON;				
				}
			}
			
			set_solen_on_off(i, sol_i->solenoid_state);		
		}
		else {
			sol_i->test_loop_cnt ++;
		}

		UARTprintf("F,%u,%u,%u,%u\n", i,	sol_i->test_loop_cnt, (uint32_t)(sol_i->solen_on_cnt/10), (uint32_t)(sol_i->solen_off_cnt/10));
		sol_i->solen_on_cnt = 0;
		sol_i->solen_off_cnt = 0;
	}
	
}


//*****************************************************************************
//
// This example application demonstrates the use of the timers to generate
// periodic interrupts.
//
//*****************************************************************************

int
main(void)
{

    uint32_t    i;
    uint32_t    temp;

    uint8_t     fsm_state;
	uint8_t     pb_fsm;						// pushbutton FSM
    uint32_t    sw1_debounce;

    uint8_t		on_error;
    uint8_t     *puart_rx;
	uint8_t		uart_rx_buf[12];			// l 4294967296

	Solenoid_Ctl *sol;

	sol = malloc(10 * sizeof(Solenoid_Ctl));
	
	if(sol == NULL) {
		while(1) { }
	}

	on_error = '0'; // continue on error
    test_time_cnt = 0;
	sw1_debounce = 0;
    fsm_state = IDLE;
	pb_fsm = BUTTON_IDLE;
	puart_rx = uart_rx_buf;
	
    //
    // Enable lazy stacking for interrupt handlers.  This allows floating-point
    // instructions to be used within interrupt handlers, but at the expense of
    // extra stack usage.
    //
	ROM_FPUEnable();
    ROM_FPULazyStackingEnable();

    //
    // Set the clocking to run directly from the crystal.
    //
     ROM_SysCtlClockSet(SYSCTL_SYSDIV_1 | SYSCTL_USE_OSC | SYSCTL_OSC_MAIN |
                       SYSCTL_XTAL_16MHZ);

    //
    // Initialize the UART and write status.
    //
    ConfigureUART();
    UARTprintf("\033[2J\n");
    UARTprintf("> ");

    //
    // Enable the GPIO ports that are used.
    //
    ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
    ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB);
    ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOC);
    ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOD);
    ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOE);
    ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);

    //
    // Enable the GPIO pins
    //
    ROM_GPIOPinTypeGPIOInput(PORT_BUTTON, PIN_BUTTON1); // pushbutton
    ROM_GPIOPadConfigSet(PORT_BUTTON, PIN_BUTTON1, GPIO_STRENGTH_8MA_SC, GPIO_PIN_TYPE_STD_WPU);


    ROM_GPIOPinTypeGPIOOutput(PORT_LED, PIN_LED_GREEN); // LED
    ROM_GPIOPinTypeGPIOOutput(PORT_LED, PIN_LED_RED);

    ROM_GPIOPinTypeGPIOOutput(PORT_SOL_OUT0, PIN_SOL_OUT0); // solenoid outputs
    ROM_GPIOPinTypeGPIOOutput(PORT_SOL_OUT1, PIN_SOL_OUT1);
    ROM_GPIOPinTypeGPIOOutput(PORT_SOL_OUT2, PIN_SOL_OUT2);
    ROM_GPIOPinTypeGPIOOutput(PORT_SOL_OUT3, PIN_SOL_OUT3);
    ROM_GPIOPinTypeGPIOOutput(PORT_SOL_OUT4, PIN_SOL_OUT4);
    ROM_GPIOPinTypeGPIOOutput(PORT_SOL_OUT5, PIN_SOL_OUT5);
    ROM_GPIOPinTypeGPIOOutput(PORT_SOL_OUT6, PIN_SOL_OUT6);
    ROM_GPIOPinTypeGPIOOutput(PORT_SOL_OUT7, PIN_SOL_OUT7);
    ROM_GPIOPinTypeGPIOOutput(PORT_SOL_OUT8, PIN_SOL_OUT8);
    ROM_GPIOPinTypeGPIOOutput(PORT_SOL_OUT9, PIN_SOL_OUT9);

    ROM_GPIOPinTypeGPIOInput(PORT_SOL_IN0_A, PIN_SOL_IN0_A);    // solenoid inputs
    ROM_GPIOPinTypeGPIOInput(PORT_SOL_IN1_A, PIN_SOL_IN1_A);
    ROM_GPIOPinTypeGPIOInput(PORT_SOL_IN2_A, PIN_SOL_IN2_A);
    ROM_GPIOPinTypeGPIOInput(PORT_SOL_IN3_A, PIN_SOL_IN3_A);
    ROM_GPIOPinTypeGPIOInput(PORT_SOL_IN4_A, PIN_SOL_IN4_A);
    ROM_GPIOPinTypeGPIOInput(PORT_SOL_IN5_A, PIN_SOL_IN5_A);
    ROM_GPIOPinTypeGPIOInput(PORT_SOL_IN6_A, PIN_SOL_IN6_A);
    ROM_GPIOPinTypeGPIOInput(PORT_SOL_IN7_A, PIN_SOL_IN7_A);
    ROM_GPIOPinTypeGPIOInput(PORT_SOL_IN8_A, PIN_SOL_IN8_A);
    ROM_GPIOPinTypeGPIOInput(PORT_SOL_IN9_A, PIN_SOL_IN9_A);

    ROM_GPIOPinTypeGPIOInput(PORT_SOL_IN0_B, PIN_SOL_IN0_B);
    ROM_GPIOPinTypeGPIOInput(PORT_SOL_IN1_B, PIN_SOL_IN1_B);
    ROM_GPIOPinTypeGPIOInput(PORT_SOL_IN2_B, PIN_SOL_IN2_B);
    ROM_GPIOPinTypeGPIOInput(PORT_SOL_IN3_B, PIN_SOL_IN3_B);
    ROM_GPIOPinTypeGPIOInput(PORT_SOL_IN4_B, PIN_SOL_IN4_B);
    ROM_GPIOPinTypeGPIOInput(PORT_SOL_IN5_B, PIN_SOL_IN5_B);
    ROM_GPIOPinTypeGPIOInput(PORT_SOL_IN6_B, PIN_SOL_IN6_B);
    ROM_GPIOPinTypeGPIOInput(PORT_SOL_IN7_B, PIN_SOL_IN7_B);
    ROM_GPIOPinTypeGPIOInput(PORT_SOL_IN8_B, PIN_SOL_IN8_B);
    ROM_GPIOPinTypeGPIOInput(PORT_SOL_IN9_B, PIN_SOL_IN9_B);

    //
    // De-energize all solenoids
    //
    for(i=0; i<10; i++)
    {
    	sol[i].solenoid_state = SOLEN_OFF;
    	sol[i].loop_cnt_setting = 0xFFFFFFFF;
    	sol[i].sensor_dbn_cnt = 0;
    	sol[i].solen_off_cnt = 0;
    	sol[i].solen_on_cnt = 0;
    	sol[i].test_loop_cnt = 0;
    	sol[i].test_wdog_cnt = 0;
		sol[i].test_error = NO_ERROR;
        set_solen_on_off(i, sol[i].solenoid_state);
    }

    //
    // Enable the peripherals used by this example.
    //
    ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER0);

    //
    // Configure the two 32-bit periodic timers.
    //
    ROM_TimerConfigure(TIMER0_BASE, TIMER_CFG_PERIODIC);
    ROM_TimerLoadSet(TIMER0_BASE, TIMER_A, 1600);   // 1600 count @ 16MHz = 100 uS

    //
    // Enable processor interrupts.
    //
    ROM_IntMasterEnable();

    //
    // Setup the interrupts for the timer timeouts.
    //
    ROM_IntEnable(INT_TIMER0A);
    ROM_TimerIntEnable(TIMER0_BASE, TIMER_TIMA_TIMEOUT);

    //
    // Enable the timers.
    //
    ROM_TimerEnable(TIMER0_BASE, TIMER_A);


    //
    // Loop forever while the timers run.
    //
    while(1)
    {
        if(ROM_UARTCharsAvail(UART0_BASE))
        {
			// echo UART
			*puart_rx = (uint8_t) ROM_UARTCharGetNonBlocking(UART0_BASE);
            ROM_UARTCharPutNonBlocking(UART0_BASE, *puart_rx);
			
			// cmd received
            if(*puart_rx == '\r')
            {
				ROM_UARTCharPutNonBlocking(UART0_BASE, '\n');
				// cmd: loop forever (0xFFFFFFFF)
				if(uart_rx_buf[0]=='l' && uart_rx_buf[1]==' ' && uart_rx_buf[2]=='0' && puart_rx-uart_rx_buf==3) {
					UARTprintf("ack: loop %u", 0xFFFFFFFF);
					for(i=0; i<10; i++)
						sol[i].loop_cnt_setting = 0xFFFFFFFF;
						
					fsm_state = RUN; // start testing
				}
				// cmd: error mode
				else if(uart_rx_buf[0]=='e' && uart_rx_buf[1]==' ' && puart_rx-uart_rx_buf==3) {
					UARTprintf("ack");
					on_error = uart_rx_buf[2];
					fsm_state = IDLE;
				}
				// cmd: pause
				else if(uart_rx_buf[0]=='s' && uart_rx_buf[1]==' ' && uart_rx_buf[2]=='a' && puart_rx-uart_rx_buf==3) {
					UARTprintf("ack");
					fsm_state = IDLE;
				}
				// cmd: clear
				else if(uart_rx_buf[0]=='c' && uart_rx_buf[1]==' ' && uart_rx_buf[2]=='a' && puart_rx-uart_rx_buf==3) {
					UARTprintf("ack");
					for(i=0; i<10; i++) {
						sol[i].loop_cnt_setting = 0xFFFFFFFF;
						sol[i].sensor_dbn_cnt = 0;
						sol[i].solen_off_cnt = 0;
						sol[i].solen_on_cnt = 0;
						sol[i].test_loop_cnt = 0;
						sol[i].test_wdog_cnt = 0;
						sol[i].test_error = NO_ERROR;
					}
					ROM_GPIOPinWrite(PORT_LED, PIN_LED_RED, 0x00);
                	test_time_cnt = 0;
				}
				// cmd: loop #
				else if(uart_rx_buf[0]=='l' && uart_rx_buf[1]==' ')				
				{
					temp = 0;
					for(i=0; i<(puart_rx-uart_rx_buf-2); i++) {
						if(is_ascii_digit(*(puart_rx-1-i)) == true) {
							temp += (*(puart_rx-1-i)-'0')*power_of_ten(i);
						}
						else {
							temp = 0;
							break;
						}										
					}
					
					if(temp != 0) { // cmd valid
						UARTprintf("ack: loop %u", temp);
						for(i=0; i<10; i++)
							sol[i].loop_cnt_setting = temp;

						fsm_state = RUN; // start testing
					}
					else {
						UARTprintf("bad");
					}
				}
				else {
					print_result(sol, test_time_cnt);
				}
				UARTprintf("> ");
				puart_rx = uart_rx_buf;
            }
            else if(puart_rx-uart_rx_buf < 11) {
				puart_rx ++;
			}

        }

        // timer 0 interrupt 100uS
        if(g_ui32Timer0Int==1)
        {
            g_ui32Timer0Int = 0;

			if(pb_fsm == BUTTON_IDLE) {
				if(ROM_GPIOPinRead(PORT_BUTTON, PIN_BUTTON1)==0x00)
					pb_fsm = BUTTON_DOWN;
			}
			else if(pb_fsm == BUTTON_DOWN) {
				if(ROM_GPIOPinRead(PORT_BUTTON, PIN_BUTTON1)==0x00) {		
					sw1_debounce ++;
					if(sw1_debounce >= (TIME_ONE_MILI_SEC*3000))    // push & hold
					{
						if(fsm_state==IDLE)
						{
							ROM_GPIOPinWrite(PORT_LED, PIN_LED_RED, PIN_LED_RED);
							test_time_cnt = 0;
							for(i=0; i<10; i++) {
								sol[i].test_loop_cnt = 0;
							}
						}
					}
				}
				else {
					if((sw1_debounce>=TIME_ONE_MILI_SEC*50) && (sw1_debounce<=TIME_ONE_MILI_SEC*3000)) {  // push, 50ms de-bounce
						if(fsm_state==IDLE)		fsm_state = RUN;
						else					fsm_state = IDLE;
					}
					sw1_debounce = 0;
					ROM_GPIOPinWrite(PORT_LED, PIN_LED_RED, 0x00);				
					pb_fsm = BUTTON_IDLE;
				}
			}

			///////////////////////////////////////////////////////////////////
            // solenoid FSM
			//
            if(fsm_state==IDLE) {
                for(i=0; i<10; i++) {
                	sol[i].solenoid_state = SOLEN_OFF;
                    set_solen_on_off(i, sol[i].solenoid_state);

                    sol[i].sensorA_state_off = sol[i].sensorA_state;
                    sol[i].sensorB_state_off = sol[i].sensorB_state;
                }

                get_senseAB_state(sol);

                ROM_GPIOPinWrite(PORT_LED, PIN_LED_GREEN, 0x00);
            }
            else if(fsm_state==RUN) {
                test_time_cnt++; // test duration

                if(test_time_cnt%10000 == 0) {
                	UARTprintf("T,%u\n", (uint32_t)(test_time_cnt/10000));
                }

                // toggling green LED during run
                if(test_time_cnt % (TIME_ONE_MILI_SEC*250) == 0) {
                    if(ROM_GPIOPinRead(PORT_LED, PIN_LED_RED) == PIN_LED_RED) {
						ROM_GPIOPinWrite(PORT_LED, PIN_LED_GREEN, 0x00);
					} 
					else {
						if(ROM_GPIOPinRead(PORT_LED, PIN_LED_GREEN) == PIN_LED_GREEN)
							ROM_GPIOPinWrite(PORT_LED, PIN_LED_GREEN, 0x00);
						else
							ROM_GPIOPinWrite(PORT_LED, PIN_LED_GREEN, PIN_LED_GREEN);
					}
                }

				///////////////////////////////////////////////////////////////////////////////////
                // get all sensor state and toggle solenoid
                get_senseAB_state(sol);
				for(i=0; i<10; i++) {
					solenoid_control_v2(i, &sol[i], on_error);
				}
            }
        }
    }
}




