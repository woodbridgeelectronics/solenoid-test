/*
 * project.h
 *
 *  Created on: Mar 20, 2017
 *      Author: sugg
 */

#ifndef PROJECT_H_
#define PROJECT_H_


#define     TIME_ONE_MILI_SEC       10  // based on 100uS timer
#define     IDLE                    0
#define     RUN                     1
#define		BUTTON_IDLE				0
#define		BUTTON_DOWN				1

#define     SOLEN_ON                0xFF
#define     SOLEN_OFF               0x00

#define		NO_ERROR				0
#define		ERROR_SET				1
#define		ERROR_CLR1				2

//*****************************************************************************
// LED & pushbutton pin definition
//*****************************************************************************

#define     PORT_LED                GPIO_PORTF_BASE
#define     PIN_LED_GREEN           GPIO_PIN_3
#define     PIN_LED_RED             GPIO_PIN_1

#define     PORT_BUTTON             GPIO_PORTF_BASE
#define     PIN_BUTTON1             GPIO_PIN_4


//*****************************************************************************
// Solenoid input pin definition
//*****************************************************************************
#define     PORT_SOL_IN0_A              GPIO_PORTB_BASE
#define     PORT_SOL_IN1_A              GPIO_PORTC_BASE
#define     PORT_SOL_IN2_A              GPIO_PORTE_BASE
#define     PORT_SOL_IN3_A              GPIO_PORTC_BASE
#define     PORT_SOL_IN4_A              GPIO_PORTD_BASE
#define     PORT_SOL_IN5_A              GPIO_PORTC_BASE
#define     PORT_SOL_IN6_A              GPIO_PORTB_BASE
#define     PORT_SOL_IN7_A              GPIO_PORTB_BASE
#define     PORT_SOL_IN8_A              GPIO_PORTD_BASE
#define     PORT_SOL_IN9_A              GPIO_PORTB_BASE

#define     PORT_SOL_IN0_B              GPIO_PORTE_BASE
#define     PORT_SOL_IN1_B              GPIO_PORTB_BASE
#define     PORT_SOL_IN2_B              GPIO_PORTD_BASE
#define     PORT_SOL_IN3_B              GPIO_PORTC_BASE
#define     PORT_SOL_IN4_B              GPIO_PORTD_BASE
#define     PORT_SOL_IN5_B              GPIO_PORTB_BASE
#define     PORT_SOL_IN6_B              GPIO_PORTE_BASE
#define     PORT_SOL_IN7_B              GPIO_PORTE_BASE
#define     PORT_SOL_IN8_B              GPIO_PORTB_BASE
#define     PORT_SOL_IN9_B              GPIO_PORTF_BASE

#define     PIN_SOL_IN0_A               GPIO_PIN_4
#define     PIN_SOL_IN1_A               GPIO_PIN_6
#define     PIN_SOL_IN2_A               GPIO_PIN_5
#define     PIN_SOL_IN3_A               GPIO_PIN_7
#define     PIN_SOL_IN4_A               GPIO_PIN_1
#define     PIN_SOL_IN5_A               GPIO_PIN_5
#define     PIN_SOL_IN6_A               GPIO_PIN_5
#define     PIN_SOL_IN7_A               GPIO_PIN_3
#define     PIN_SOL_IN8_A               GPIO_PIN_0
#define     PIN_SOL_IN9_A               GPIO_PIN_1

#define     PIN_SOL_IN0_B               GPIO_PIN_1
#define     PIN_SOL_IN1_B               GPIO_PIN_7
#define     PIN_SOL_IN2_B               GPIO_PIN_2
#define     PIN_SOL_IN3_B               GPIO_PIN_4
#define     PIN_SOL_IN4_B               GPIO_PIN_3
#define     PIN_SOL_IN5_B               GPIO_PIN_2
#define     PIN_SOL_IN6_B               GPIO_PIN_4
#define     PIN_SOL_IN7_B               GPIO_PIN_0
#define     PIN_SOL_IN8_B               GPIO_PIN_0
#define     PIN_SOL_IN9_B               GPIO_PIN_2

//*****************************************************************************
// Solenoid output pin definition
//*****************************************************************************
#define     PORT_SOL_OUT0               GPIO_PORTA_BASE
#define     PORT_SOL_OUT1               GPIO_PORTA_BASE
#define     PORT_SOL_OUT2               GPIO_PORTA_BASE
#define     PORT_SOL_OUT3               GPIO_PORTE_BASE
#define     PORT_SOL_OUT4               GPIO_PORTB_BASE
#define     PORT_SOL_OUT5               GPIO_PORTE_BASE
#define     PORT_SOL_OUT6               GPIO_PORTA_BASE
#define     PORT_SOL_OUT7               GPIO_PORTD_BASE
#define     PORT_SOL_OUT8               GPIO_PORTA_BASE
#define     PORT_SOL_OUT9               GPIO_PORTA_BASE

#define     PIN_SOL_OUT0                GPIO_PIN_6
#define     PIN_SOL_OUT1                GPIO_PIN_7
#define     PIN_SOL_OUT2                GPIO_PIN_5
#define     PIN_SOL_OUT3                GPIO_PIN_3
#define     PIN_SOL_OUT4                GPIO_PIN_6
#define     PIN_SOL_OUT5                GPIO_PIN_2
#define     PIN_SOL_OUT6                GPIO_PIN_4
#define     PIN_SOL_OUT7                GPIO_PIN_6
#define     PIN_SOL_OUT8                GPIO_PIN_3
#define     PIN_SOL_OUT9                GPIO_PIN_2


#endif /* PROJECT_H_ */
